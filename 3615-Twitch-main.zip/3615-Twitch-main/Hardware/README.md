# 3615-Twitch :: Hardware

This project uses an ESP8266 and a Minitel.

Based on this schema, connect the ESP8266 to the DIN5 female:

![schema](schema.png)
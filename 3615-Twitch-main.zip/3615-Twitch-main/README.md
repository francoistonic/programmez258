# 3615-Twitch

As a streamer
I want to have a bot twitch to display the first frame of a random image of giphy from a prompt

When the bot is launched

```
!3615 your_prompt
```

from an user on your chat it will display an image on your minitel.

## Hardware Requirements

- Minitel 1B
- ESP8266 (Nodemcu ESP8266 ESP-12F)
- Resistors : 1x 4.7KΩ, 1x 1kΩ
- Wires
- Breadboard

# 3615-Twitch :: DemoServer

## Installation

```sh
pnpm install
```

## Dev

```sh
pnpm dev
```

## Play with the Minitel

1. Start your Minitel
2. Start your ESP8266 connected to the DIN5
3. On the web page :
   1. Change the ip which is displayed
   2. Load an image
   3. Enjoy!
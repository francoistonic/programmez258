# WorkAdventure Map Starter Kit - Src Folder

In this directory you can put your scripts and other source code files.
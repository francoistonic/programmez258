using PyCall

pd = pyimport("pandas")

df = pd.DataFrame(Dict(:A => [40, 25, 30], :B => [40, 25, 30]))

println(df.describe())

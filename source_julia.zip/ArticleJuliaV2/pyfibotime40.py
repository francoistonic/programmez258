import time


def fibo(n):
    if n <= 1:
        return n
    else:
        return fibo(n - 1) + fibo(n - 2)


for i in range(10):
    start_time = time.time()
    fibo(40)
    end_time = time.time()
    print("%s" % (end_time - start_time))
